const express = require("express");
const cors = require("cors");
const bodyparser = require("body-parser");
const router = express.Router();
router.use(bodyparser.json());
const ctrs = require("../controller/Product Controller");
router.use(cors());
router.get("/display", ctrs.getAll);

router.post("/add-product", ctrs.add);
module.exports = router;
