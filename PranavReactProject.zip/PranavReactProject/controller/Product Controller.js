const bodyparser = require("body-parser");
const Product = require("../Models/Product Model");
const { Console } = require("console");
exports.getAll = async (req, res) => {
  await Product.find().then((product) => res.send(product));
};

exports.add = async (req, res) => {
  let product = new Product({
    productCode: req.body.productCode,
    name: req.body.name,
    quantity: req.body.quantity,
    price: req.body.price,
    status: req.body.status,
    date: req.body.date,
  });
  result = await product.save().then((product) => {
    res.send(product);
  });
};
