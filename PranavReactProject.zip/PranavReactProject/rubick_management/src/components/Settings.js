import React from "react";

export default function Settings() {
  return (
    <div>
      <h1>
        <b>Settings</b>
      </h1>
      <ul>
        <li>Change username</li>
        <li>Change password</li>
      </ul>
    </div>
  );
}
