import React from "react";

export default function Home() {
  return (
    <div style={{ wordWrap: "break-word", width: "100%" }}>
      <h1 style={{ color: "#345aee", fontSize: "1.8rem" }}>
        Welcome to Rubick.ai.
      </h1>
      <p style={{ color: "#89898b", fontWeight: "bold" }}>
        {" "}
        Check our products page for more information.
      </p>
    </div>
  );
}
