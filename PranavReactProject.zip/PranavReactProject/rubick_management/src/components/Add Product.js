import React, { useState } from "react";
import { Form, Input, Select, Row, Button } from "antd";
import axios from "axios";
import { Switch } from "antd";

export default function Addproduct() {
  const [status, setStatus] = useState(false);
  const onFinish = (e) => {
    let state = {
      productCode: e.productCode,
      name: e.Name,
      status: status === true ? "active" : "Inactive",
      quantity: e.quantity,
      price: e.Price,
      date: Date(),
    };

    axios
      .post("/add-product", state)
      .then(() => alert(`Product Added Succesfully`))
      .catch((err) => console.log(err));
  };

  const onChange = (checked) => {
    setStatus(checked);
  };

  return (
    <div>
      <div>
        <h2>
          <b>New Products</b>
        </h2>
      </div>
      <div>
        <Form onFinish={onFinish} layout="vertical">
          <Row>
            <Form.Item
              name="productCode"
              label="Product Code"
              rules={[
                {
                  whitespace: true,
                  required: true,
                },
                {
                  pattern: new RegExp(/^\d+$/g),
                  message: "Incorrect format",
                },
                {
                  min: 4,
                  message: "Produuct Code must be greater than 3 digits",
                },
              ]}
            >
              <Input
                style={{ width: "400px", height: "50px" }}
                placeholder="Product Code"
              />
            </Form.Item>

            <Form.Item
              name="status"
              label="Status"
              style={{ marginLeft: "200px" }}
            >
              <span>
                <Switch onChange={onChange} />
                <p style={{ color: status === true ? "green" : "red" }}>
                  {status === true ? "Active" : "Inactive"}
                </p>
              </span>
            </Form.Item>
          </Row>

          <Form.Item
            name="Name"
            label="Name"
            rules={[
              {
                whitespace: true,
                required: true,
              },
              {
                pattern: new RegExp(/^[A-Za-z]+$/),
                message: "Incorrect format",
              },
              {
                min: 3,
                message: "Product Name must be greater than 2 letters",
              },
            ]}
          >
            <Input
              style={{ width: "595px", height: "50px" }}
              placeholder="Product Name"
            />
          </Form.Item>
          <Form.Item
            name="quantity"
            label="Quantity"
            rules={[
              {
                whitespace: true,
                required: true,
              },
              {
                pattern: new RegExp(/^\d+$/g),
                message: "Incorrect format",
              },
              {
                max: 100,
                message: "Quantity must be less than 100",
              },
              {
                min: 1,
                message: "Quantity must be more than 1",
              },
            ]}
          >
            <Input
              style={{ width: "400px", height: "50px" }}
              placeholder="Quantity"
            />
          </Form.Item>
          <Form.Item
            name="Price"
            label="Price"
            rules={[
              {
                whitespace: true,
                required: true,
              },
              {
                pattern: new RegExp(/^\d+$/g),
                message: "Incorrect format",
              },
            ]}
          >
            <Input
              style={{ width: "400px", height: "50px" }}
              placeholder="Price"
            />
          </Form.Item>
          <Form.Item>
            <Button
              type="primary"
              htmlType="reset"
              shape="round"
              style={{
                color: "darkgray",
                backgroundColor: "grey",
                width: "175px",
                height: "40px",
              }}
            >
              Cancel
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              shape="round"
              style={{ marginLeft: "20px", width: "175px", height: "40px" }}
            >
              Submit
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
}
