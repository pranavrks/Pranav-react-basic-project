const express = require("express");
const cors = require("cors");
const bodyparser = require("body-parser");
const app = express();
const mongoose = require("mongoose");
const PORT = process.env.PORT || 9000;
const URL =
  "mongodb+srv://pranav:rubikai@cluster0.qshaitu.mongodb.net/?retryWrites=true&w=majority";

app.use(bodyparser.json());
app.use("/", require("./Routes/Product"));
app.use(cors());

mongoose.connect(URL);
const con = mongoose.connection;

con.on("open", () => console.log("Database Connected Successfully"));
app.listen(9000, () => {
  console.log(`App has started running at ${PORT}`);
});
